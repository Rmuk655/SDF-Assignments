#!/bin/bash
date "+%b %d, %Y"