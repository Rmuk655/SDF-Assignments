#!/bin/bash
echo "Hello World"
echo "This is a sample script"